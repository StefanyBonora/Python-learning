"""
Leia uma distancia em milhas e apresente-a convertida em km. A fórmula de conversão é : k = 1.61*m
sendo k a velocidade km e m em milhas.

*logica:
passo 1. ler dados de velocidade em milhas do usuario
passo 2. realizar a conversão
passo 3. apresentar os dados para o usuario

"""

print("***CONVERSÃO milhas PARA quilômetros***")
print("Boa noite usuário \n informe a distancia em milhas:") #1. ler os dados de velocidade em m do usuário.
m = float(input())
k = 1.61*m  # passo 2. realizar a conversão.
k = round(k,2) #round um função que serve para limitar as casas após a virgula

#3. imprimir a conversão
print(f'A conversão em km é:{k}') #3. imprimir a conversão