"""
Leia uma temperatura em graus celcius e apresente-a convertida em graus fahrenhait.
A formula de conversão é: f = c*(9.0/5.0)+32.0 ,
 sendo f a temperatura em fahrenheit e c a temperatura em Celsius.

 *logica:

passo 1. pedir ao usuario a entrada da temperatura em Celcius
passo 2. converter os dados para celcius
passo 3. imprimir os resultado para o usuario

"""

# 1. ler os dados de temperatura em Celcius do usuário.
print("Boa noite usuário \n informe a temperatura em Celcius:")
c = float(input())

#2. Realizar a coversão
f = c*(9.0/5.0)+32.0

#round um função que serve para limitar as casas após a virgula
f = round(f,2)

#3. imprimir a conversão
print(f'A conversão em graus fahrenheit é: {f}')