"""
Leia um numero real e imprima o resultado do quadrado desse numero
"""
#entrada de dados
print('escreva um numero real')
num = int(input())

#calculo de potencia
#resultado = num ** 2

#saida de dados 

print(f'O resultado ao quadrado do numero real é {num ** 2}')