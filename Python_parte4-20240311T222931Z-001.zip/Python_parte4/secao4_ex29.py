"""
Leia quatro notas, cálcule a média aritimética e imprima o resultado.

Lógica
passo 1. ler as quatro notas do usuário
passo 2. fazer os cálculos
passo 3. imprimir os dados ao usuário
"""

print('***Cálculo de média***')

# Data reading
print("Insira a primeira nota: ")
nota1 = float(input())
print("Insira a segunda nota: ")
nota2 = float(input())
print("Insira a terceira nota: ")
nota3 = float(input())
print("Insira a quarta nota: ")
nota4 = float(input())

#data calculation average
media = ((nota1+nota2+nota3+nota4)/4)
media = round(media,3)

#result
print(f'Média é igual a:{media}')