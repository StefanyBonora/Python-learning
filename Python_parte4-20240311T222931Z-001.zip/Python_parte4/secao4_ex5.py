"""
leia um  numero real e imprima a quinta parte desse numero
"""

print('Escreva um numero real')
num = int(input())

resultado = num / 5

print(f'A quinta parte do numero real é: {resultado}')


