"""
Peca para o usuario escrever 3 valores inteiro e imprima a soma deles

"""

#Entrada dos dados
print("Escreva o primeiro numero numero real")
numero1 = int(input())
print("Escreva o segundo numero numero real")
numero2 = int(input())
print("Escreva o terceiro numero numero real")
numero3 = int(input())

#calculo dos inteiros
soma = numero1 + numero2 + numero3

#imprima a soma
print(f"A soma dos numeros é igual = {soma}")
