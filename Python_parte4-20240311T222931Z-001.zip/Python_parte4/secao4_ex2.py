""" 
FACA UM PROGRAMA QUE LEIA UM NUMERO REAL E IMPRIMA

"""
import locale

# Desafio: aceitar o numero real em portugues 
print("Escreva um numero real")
numero = float(input())

#SAIDA DE DADOS
print(f'O numero digitado é: \n {numero}')
