"""
Leia uma velocidade em m/s e apresente-a convertida em km/h. A fórmula de conversão é : k = m*3.6
sendo k a velocidade km/h e m m/s.

*logica:

passo 1. ler dados de velocidade em km/h do usuario
passo 2. realizar a conversão
passo 3. apresentar os dados para o usuario

"""

print("***CONVERSÃO m/s PARA km/h***")
print("Boa noite usuário \n informe a velocidade em m/s:") #1. ler os dados de velocidade em m/s do usuário.
m = float(input())
k = m*3.6  # passo 2. realizar a conversão
k = round(k,2) #round um função que serve para limitar as casas após a virgula

#3. imprimir a conversão
print(f'A conversão em km/h é:{k}') #3. imprimir a conversão