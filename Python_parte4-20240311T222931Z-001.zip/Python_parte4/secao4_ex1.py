"""
1) Faca um programa que leia um numero inteiro e o imprima

"""
# ENTRADA DE DADOS
print("Escreva um numero inteiro")
numero = int(input())

# SAIDA DE DADOS
print(f'O numero digitado é:{numero}')
