"""
Leia uma temperatura em graus fahrenheit e apresente-a convertida em grau Celsius.
A fórmula de conversão é: C=5.0(F-32.0)/9.0, sendo C a temperatura em Celsius e F a temperatura em fahrenheit
* Lógica:
1. ler os dados de temperatura em Fahrenheit do usuário.
2. Realizar a coversão2. Realizar a coversão
3. imprimir a conversão
"""

# 1. ler os dados de temperatura em Fahrenheit do usuário.
print("Boa noite usuário \n informe a temperatura em Fahrenheit:")
f = float(input())

#2. Realizar a coversão
c = 5.0 * (f-32.0) / 9.0

#round um função que serve para limitar as casas após a virgula
c = round(c,2)

#3. imprimir a conversão
print(f'A conversão em graus Celcius é: {c}')


# ver como faz para diminuir as casas depois da virgula